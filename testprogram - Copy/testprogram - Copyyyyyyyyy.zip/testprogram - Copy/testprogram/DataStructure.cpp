
#include <iostream>
#include "Program.h"
#include<fstream>
using namespace std;


int main()
{
	Program a;
    a.readdata();
	a.run();



}

